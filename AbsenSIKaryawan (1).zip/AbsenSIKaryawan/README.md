# AbsenSIKaryawan
Absensi dan Sistem Informasi Karyawan berbasis web


-> Absen Karyawan - SIKaryawan

Absen Karyawan - Sistem informasi karyawan merupakan aplikasi absensi berbasis web, yang dibuat untuk memenuhi kebutuhan perusahaan atau instansi yang membutuhkan aplikasi absensi karyawan.

-> Fitur - fitur aplikasi : 
1.admin, dimana admin bisa mengontrol aplikasi, ini seperti menambahkan, melihat, mengubah atau menghapus data.

2.Sistem absensi karyawan, sistem ini memungkinkan setiap karyawan melakukan absensi berdasarkan sesi nya masing - masing.  Untuk mencegah penyalahgunaan data.

-> Login default admin : 
  1. username = admin
  2. password = admin
  
-> Login default karyawan : 
  1. username = user
  2. password = user
  
-> Catatan(PENTING) :
    <i style="color: yellow;">Sebelum mengimport database, pastikan anda membuat database sesuai dengan nama database yang ada di dalam folder db, yaitu 'karyawansi'</i>
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Aplikasi ini adalah aplikasi open source, anda bisa menggunakan aplikasi saya ini untuk apapun. 
Tetapi jika anda berkenan, silahkan donasi :
1. Paypal = https://paypal.me/Zeppy19?locale.x=id_ID
